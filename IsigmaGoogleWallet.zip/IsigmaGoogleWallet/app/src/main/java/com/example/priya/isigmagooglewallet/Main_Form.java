package com.example.priya.isigmagooglewallet;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Main_Form extends AppCompatActivity {
    Button mPayButton;
    EditText mNameField;
    EditText mIdField;
    private static final String CUSTOMER_ID =
            "com.example.priya.isigmagooglewallet.customer_id";
    private static final String CUSTOMER_NAME =
            "com.example.priya.isigmagooglewallet.customer_name";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main__form);


        mPayButton = (Button) findViewById(R.id.pay_btn);

        mPayButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mIdField = (EditText) findViewById(R.id.cust_id);
                mNameField = (EditText) findViewById(R.id.cust_name);
                String id = mIdField.getText().toString();
                String name = mNameField.getText().toString();
                Intent i = intentPay(Main_Form.this , name, id);
                startActivity(i);
            }
        });

    }
    public static Intent intentPay(Context context, String name, String id) {
        Intent intent = new Intent(context , Pay_type.class);
        //add Customer's Name and ID to intent
        intent.putExtra(CUSTOMER_NAME , name);
        intent.putExtra(CUSTOMER_ID , id);
        return intent;
    }
}
