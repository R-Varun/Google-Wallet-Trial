package com.example.priya.isigmagooglewallet;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Toast;

public class Pay_type extends AppCompatActivity {
    private static final String CUSTOMER_ID =
            "com.example.priya.isigmagooglewallet.customer_id";
    private static final String CUSTOMER_NAME =
            "com.example.priya.isigmagooglewallet.customer_name";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pay_type);

        Toast toast = Toast.makeText(getApplicationContext() , getIntent().getStringExtra(CUSTOMER_ID) +
                "\n" + getIntent().getStringExtra(CUSTOMER_NAME), Toast.LENGTH_LONG);
        toast.show();
    }
}
